# extract/load_csv_staging.py

import os
import logging
import pandas as pd
from sqlalchemy import text
from datetime import datetime


def limpar_staging(ano_censo, engine):
    """Remove dados do ano informado na staging."""
    logging.info("Limpando staging para ano %s...", ano_censo)
    with engine.begin() as conn:
        conn.execute(
            text("DELETE FROM staging.censo_escolar_matricula WHERE NU_ANO_CENSO = :ano"),
            {"ano": ano_censo}
        )
    logging.info("Staging limpa para ano %s.", ano_censo)


def carregar_csv_para_staging(path_csv, ano_censo, engine):
    """Carrega o CSV em chunks para a tabela staging.censo_escolar_matricula."""

    logging.info("Início da carga CSV → Staging. Arquivo: %s", path_csv)

    if not os.path.exists(path_csv):
        raise FileNotFoundError(f"Arquivo CSV inexistente: {path_csv}")

    # Colunas de interesse
    columns = [
        "NU_ANO_CENSO","SG_UF","CO_MUNICIPIO","NO_MUNICIPIO",
        "CO_ENTIDADE","NO_ENTIDADE","TP_DEPENDENCIA",
        "QT_MAT_INF","QT_MAT_FUND","QT_MAT_MED","QT_MAT_PROF"
    ]

    chunks = pd.read_csv(
        path_csv,
        sep=";",          # ajuste se necessário
        encoding="latin1",
        chunksize=100_000,
        low_memory=False
    )

    total = 0
    
    for i, chunk in enumerate(chunks, start=1):
        df = chunk[columns]
        df["NU_ANO_CENSO"] = ano_censo  # força o ano do pipeline

        df = df[columns]

        df.to_sql(
            "censo_escolar_matricula",
            schema="staging",
            con=engine,
            if_exists="append",
            index=False
        )

        total += len(df)
        logging.info("Chunk %s carregado: %s linhas (total: %s)", i, len(df), total)

    logging.info("Carga para staging concluída. Total linhas: %s", total)