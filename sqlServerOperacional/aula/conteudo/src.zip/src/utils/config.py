# utils/config.py

DB_CONFIG = {
    "SERVER": r".\SQLEXPRESS",
    "DATABASE": "DW_Educacao",
    "DRIVER": "ODBC Driver 18 for SQL Server",
    "TRUSTED_CONNECTION": True
}

# Caminho padrão do arquivo CSV
PATH_CSV = r"../data/microdados_ed_basica_2023.csv"

# Ano padrão do Censo
ANO_CENSO_DEFAULT = 2023



#odbcad32