# utils/db_connection.py

from sqlalchemy import create_engine
from .config import DB_CONFIG

def get_engine():
    """Cria a engine SQLAlchemy para SQL Server."""
    
    if DB_CONFIG["TRUSTED_CONNECTION"]:
        conn_str = (
            f"mssql+pyodbc://@{DB_CONFIG['SERVER']}/"
            f"{DB_CONFIG['DATABASE']}?"
            f"driver={DB_CONFIG['DRIVER'].replace(' ', '+')}"
            f"&trusted_connection=yes&Encrypt=no"
        )
    else:
        conn_str = (
            f"mssql+pyodbc://{DB_CONFIG['USER']}:{DB_CONFIG['PASSWORD']}@"
            f"{DB_CONFIG['SERVER']}/{DB_CONFIG['DATABASE']}?"
            f"driver={DB_CONFIG['DRIVER'].replace(' ', '+')}"
        )

    return create_engine(conn_str, fast_executemany=True)
